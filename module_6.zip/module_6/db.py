from sqlalchemy import create_engine, Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
engine = create_engine("sqlite:///mydb.db", echo=True)
# engine = create_engine('postgresql://postgres:azizbek11@localhost/example_db')

Base = declarative_base()
metadata = Base.metadata
Session = sessionmaker(bind=engine)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    user_teg_id = Column(String, unique=True)
    username = Column(String)
    created = Column(DateTime)
    messages = relationship("Message", back_populates="user")


class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    text = Column(String())
    user_id = Column(Integer, ForeignKey("users.id"))
    user = relationship("User", back_populates="messages")

Base.metadata.create_all(engine)